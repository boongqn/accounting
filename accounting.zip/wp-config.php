<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'accounting');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'secrect');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'QcrQ8PbyLl(U&+(k@w)a{dk!r-G.bPd,,rO!G.c6<g:RXHQsrde`|hW2kX5iC:l_');
define('SECURE_AUTH_KEY',  'Hxo^[j%v6;dGwmYXQaJA) K^Dk9c*gGk^Lq@YVX&ol=NPGqj4N47}uYovzEj%u f');
define('LOGGED_IN_KEY',    'cH}`9!%$`_^6uIf(!|olC-y9p+u$ _a7-8kIhAL<|KCo;jY}{KNRcPawPHMxlw%t');
define('NONCE_KEY',        'pZJMHzFW?!*GK/lKnAa=:rzX2Z/6[KUBG1SVcYtD;~1WCrg%kXv=gc41GL;q1LV_');
define('AUTH_SALT',        '6mS[Prp7Dp0Tl7owhq6k&%kD+m2.tP:b:^R1=-lp#[G,WExyR`HAeg71 En]F]6;');
define('SECURE_AUTH_SALT', ']hn,p1uYa>yo?fGaEB^~%W#Yga|ySNvU_#OrtTE7 ;3{Q*M}.[wM|(fZ7UhVteKN');
define('LOGGED_IN_SALT',   'Q_O=D4P&<BZg`k%G0Y3K@Ug,PV8j5Ag6{-d79|-S{ N_wPm-~>^H[q%=s{PTBqmW');
define('NONCE_SALT',       '=pjq?$c[V~XBC%9>%8$wiIx)]-*lm#jsuq5GQb(J6Kuc%qKwO<WW2[_ZvwiK;7Ca');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
